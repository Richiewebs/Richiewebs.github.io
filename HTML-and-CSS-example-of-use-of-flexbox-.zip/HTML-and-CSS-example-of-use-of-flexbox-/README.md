# HTML and CSS example of use of flexbox 
 This codes uses the concept of flexbox to solve a QR code scan webpage challenge
